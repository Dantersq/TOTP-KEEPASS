﻿using KeePass.Plugins;
using KeePassLib;
using KeePassLib.Security;
using OtpNet;
using QRCoder;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ClassLibrary2
{
    public sealed class ClassLibrary2Ext : Plugin
    {
        private IPluginHost m_host = null;
        private const string TotpSecretKeyName = "TOTP Secret";

        public override bool Initialize(IPluginHost host)
        {
            m_host = host;

            // Log in to open and create database events
            m_host.MainWindow.FileOpened += OnDatabaseOpened;
            m_host.MainWindow.FileCreated += OnNewDatabase;

            return true;
        }

        private void OnNewDatabase(object sender, EventArgs e)
        {
            try
            {
                // Hiding the main KeePass window
                m_host.MainWindow.Hide();

                // Generate a new TOTP secret with a length of 8 characters (40 bits)
                string totpSecret = GenerateCustomBase32Secret(8);
                if (string.IsNullOrEmpty(totpSecret))
                {
                    MessageBox.Show("Failed to generate TOTP secret.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    m_host.MainWindow.Show();
                    return;
                }

                // Create a QR code for the TOTP secret
                var qrCodeImage = GenerateQrCode(totpSecret);
                if (qrCodeImage == null)
                {
                    MessageBox.Show("Failed to generate QR kod.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    m_host.MainWindow.Show();
                    return;
                }

                // Display the QR code in the dialog box
                using (var form = new Form())
                {
                    form.Text = "Scan QR kod";
                    form.Width = 400;
                    form.Height = 400;

                    var pictureBox = new PictureBox
                    {
                        Image = qrCodeImage,
                        Dock = DockStyle.Fill
                    };
                    form.Controls.Add(pictureBox);

                    form.ShowDialog();
                }

                // Save the TOTP secret in the database
                var newEntry = new PwEntry(true, true);
                newEntry.Strings.Set("Title", new ProtectedString(false, "TOTP Secret Entry"));
                newEntry.Strings.Set(TotpSecretKeyName, new ProtectedString(true, totpSecret));

                m_host.Database.RootGroup.AddEntry(newEntry, true);

                MessageBox.Show("The TOTP secret has been stored in the database.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while creating the database: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Showing the main KeePass window
                m_host.MainWindow.Show();
            }
        }

        private void OnDatabaseOpened(object sender, EventArgs e)
        {
            try
            {
                var totpEntry = FindTotpEntry();

                if (totpEntry != null)
                {
                    var totpSecretProtected = totpEntry.Strings.Get(TotpSecretKeyName);
                    if (totpSecretProtected == null)
                    {
                        MessageBox.Show("TOTP secret not found in the selected record.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Get the TOTP secret from the protected string
                    string totpSecret = totpSecretProtected.ReadString();

                    if (string.IsNullOrEmpty(totpSecret))
                    {
                        MessageBox.Show("TOTP secret is empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        CloseDatabase();
                        return;
                    }

                    // Convert Base32 secret to bytes
                    byte[] secretKey;
                    try
                    {
                        secretKey = Base32Encoding.ToBytes(totpSecret);
                        if (secretKey == null || secretKey.Length == 0)
                            throw new Exception("Secret key is incorrect.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Failed to decode TOTP secret: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        CloseDatabase();
                        return;
                    }

                    // Create a Totp object
                    Totp totp;
                    try
                    {
                        totp = new Totp(secretKey);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Failed to create a TOTP object: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        CloseDatabase();
                        return;
                    }

                    // Hiding the main KeePass window
                    m_host.MainWindow.Hide();

                    // Request the code from the user
                    string userInput = PromptForTotpCode();

                    if (string.IsNullOrEmpty(userInput))
                    {
                        MessageBox.Show("TOTP code not entered. Access denied.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        CloseDatabase();
                        return;
                    }

                    // Checking the code
                    bool isValid = false;
                    try
                    {
                        isValid = totp.VerifyTotp(userInput, out long timeStepMatched);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error during TOTP code verification: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        CloseDatabase();
                        return;
                    }

                    if (isValid)
                    {
                        MessageBox.Show("TOTP code is valid.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Invalid TOTP code. Access denied.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        CloseDatabase();
                    }
                }
                else
                {
                    MessageBox.Show("No record with TOTP secret found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred when opening the database: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Showing the main KeePass window
                m_host.MainWindow.Show();
            }
        }

        private PwEntry FindTotpEntry()
        {
            // Search for a record with TOTP secret in the database
            foreach (var entry in m_host.Database.RootGroup.GetEntries(true))
            {
                if (entry.Strings.ReadSafe("Title") == "TOTP Secret Entry")
                {
                    return entry;
                }
            }

            return null;
        }

        private string GenerateCustomBase32Secret(int length)
        {
            if (length != 8) // 8 characters = 40 bits
            {
                throw new ArgumentException("The length of the secret must be exactly 8 characters for 40 bits.");
            }

            const string allowedChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"; // A-Z и 2-8
            var random = new Random();
            var secret = new char[length];

            for (int i = 0; i < length; i++)
            {
                secret[i] = allowedChars[random.Next(allowedChars.Length)];
            }

            return new string(secret);
        }

        private Bitmap GenerateQrCode(string secret)
        {
            // Generate URL for QR code
            var otpUrl = $"otpauth://totp/KeePass:User?secret={secret}&issuer=KeePass";

            try
            {
                using (var qrGenerator = new QRCodeGenerator())
                {
                    var qrCodeData = qrGenerator.CreateQrCode(otpUrl, QRCodeGenerator.ECCLevel.Q);
                    using (var qrCode = new QRCode(qrCodeData))
                    {
                        return qrCode.GetGraphic(5);
                    }
                }
            }
            catch
            {
                return null;
            }
        }

        private string PromptForTotpCode()
        {
            using (var form = new Form())
            {
                form.Text = "Enter the TOTP code";
                form.Width = 300;
                form.Height = 150;
                form.StartPosition = FormStartPosition.CenterScreen;

                var label = new Label() { Left = 20, Top = 20, Text = "Enter your TOTP code:", AutoSize = true };
                var textBox = new TextBox() { Left = 20, Top = 50, Width = 240 };
                var confirmation = new Button() { Text = "OK", Left = 190, Width = 70, Top = 80, DialogResult = DialogResult.OK };

                confirmation.Click += (sender, e) => { form.Close(); };
                form.Controls.Add(label);
                form.Controls.Add(textBox);
                form.Controls.Add(confirmation);

                form.AcceptButton = confirmation;
                form.CancelButton = confirmation;

                // Show the dialog and return the code
                var dialogResult = form.ShowDialog();

                if (dialogResult != DialogResult.OK || string.IsNullOrWhiteSpace(textBox.Text))
                {
                    return null; // The window is closed or the field is empty
                }

                return textBox.Text.Trim();
            }
        }

        private bool VerifyCustomTotpCode(string secret, string code)
        {
            if (string.IsNullOrEmpty(code))
                return false;

            byte[] secretKey;
            try
            {
                secretKey = Base32Encoding.ToBytes(secret);
            }
            catch
            {
                return false;
            }

            if (secretKey == null || secretKey.Length == 0)
                return false;

            var otp = new Totp(secretKey);
            return otp.VerifyTotp(code, out _);
        }

        private void CloseDatabase()
        {
            try
            {
                
                m_host.MainWindow.Close();
                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to close KeePass: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public override void Terminate()
        {
            // Freeing resources when the plugin is terminated
        }
    }
}
